# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""Arepyextras Copernicus DEM Extractor WEB API"""

from __future__ import annotations

import json
import os
import warnings
from enum import Enum
from pathlib import Path

from arepytools.io.metadata import RasterInfo
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field, model_validator

from arepyextras.copernicus_dem_extractor.core import extract_data
from arepyextras.copernicus_dem_extractor.core.extractor import EmptyRegionWarning

COPERNICUS_DEM_FOLDER = os.environ.get("COPERNICUS_DEM_FOLDER")
if COPERNICUS_DEM_FOLDER is None:
    raise RuntimeError("DEM not found")

COPERNICUS_DEM_PATH = Path(COPERNICUS_DEM_FOLDER)
DEM_INDEX_FILE_PATH = COPERNICUS_DEM_PATH.joinpath("demIndex.xml")
EGM2008_1_TIF_FILE_PATH = COPERNICUS_DEM_PATH.joinpath("egm2008-1.tif")
EGM2008_2_5_TIF_FILE_PATH = COPERNICUS_DEM_PATH.joinpath("egm2008-2.5.tif")


class DEMName(str, Enum):
    """Supported DEM models and datasets"""

    copernicus = "copernicus"
    other = "other"


class VerticalCoordinatesSystems(str, Enum):
    """Supported vertical coordinates system corresponding to the returned data"""

    wgs84 = "wgs84"
    egm2008 = "egm2008"


class EGM2008GeoidResolution(Enum):
    """EGM2008 Geoid Resolution to be used when converting extracted data to WGS84"""

    high = "high"  # resolution is 1
    low = "low"  # resolution is 2.5


class ExtractionROI(BaseModel):
    min_latitude: float = Field(allow_inf_nan=False, ge=-90, le=90)
    max_latitude: float = Field(allow_inf_nan=False, ge=-90, le=90)
    min_longitude: float = Field(allow_inf_nan=False, ge=-180, le=180)
    max_longitude: float = Field(allow_inf_nan=False, ge=-180, le=180)
    output_vertical_coordinates_system: VerticalCoordinatesSystems = VerticalCoordinatesSystems.wgs84
    egm2008_geoid_resolution: EGM2008GeoidResolution = EGM2008GeoidResolution.high

    @model_validator(mode="after")
    def validate_roi_boundaries(self) -> ExtractionROI:
        """Validating ROI boundaries to assert that maximum values are greater than minimum values.

        Returns
        -------
        ExtractionROI
            validated ExtractedROI class

        Raises
        ------
        ValueError
            if maximum latitude is lower than minimum latitude
        ValueError
            if maximum longitude is lower than minumum longitude
        """
        if not self.max_latitude > self.min_latitude:
            raise ValueError("MAX latitude must be higher than MIN latitude")
        if not self.max_longitude > self.min_longitude:
            raise ValueError("MAX longitude must be higher than MIN longitude")
        return self

    def to_tuple(self) -> tuple[float, float, float, float]:
        """Converting input roi model to lat/lon coordinates tuple.

        Returns
        -------
        tuple[float, float, float, float]
            minimum longitude,
            maximum longitude,
            minimum latitude,
            maximum latitude
        """
        return (self.min_longitude, self.max_longitude, self.min_latitude, self.max_latitude)


class ResponseData(ExtractionROI):
    dem_type: DEMName
    elevation_data: str
    raster_info: dict
    warning: str | None = None


app = FastAPI()


@app.post("/dem_model/{dem_type}/", response_model=ResponseData)
async def query_dem(dem_type: DEMName, roi: ExtractionROI) -> ResponseData | HTTPException:
    """Querying the selected DEM dataset and extracting data based on the user input ROI request.

    Parameters
    ----------
    dem_type : DEMName
        DEM dataset from which extract data
    roi : ExtractionROI
        user's extraction request

    Returns
    -------
    ResponseData
        response data to user request
    """
    if dem_type != DEMName.copernicus:
        return HTTPException(status_code=400, detail=f"{dem_type} DEM not supported yet")

    # extracting data from DEM based on user input request
    if roi.output_vertical_coordinates_system != VerticalCoordinatesSystems.wgs84:
        egm2008_tif_path = None
    elif roi.egm2008_geoid_resolution == EGM2008GeoidResolution.high:
        egm2008_tif_path = EGM2008_1_TIF_FILE_PATH
    elif roi.egm2008_geoid_resolution == EGM2008GeoidResolution.low:
        egm2008_tif_path = EGM2008_2_5_TIF_FILE_PATH

    # extracting data from DEM
    with warnings.catch_warnings(record=True) as caught_warnings:
        data, raster_info = extract_data(
            dem_index_file_path=DEM_INDEX_FILE_PATH, roi=roi.to_tuple(), path_to_egm2008_tif=egm2008_tif_path
        )
        empty_roi_warning = [f for f in caught_warnings if f.category is EmptyRegionWarning]

    return ResponseData(
        min_longitude=roi.min_longitude,
        max_longitude=roi.max_longitude,
        min_latitude=roi.min_latitude,
        max_latitude=roi.max_latitude,
        egm2008_geoid_resolution=roi.egm2008_geoid_resolution,
        output_vertical_coordinates_system=roi.output_vertical_coordinates_system,
        dem_type=dem_type,
        raster_info=_raster_info_to_dict(raster_info=raster_info),
        elevation_data=json.dumps(data.tolist()),
        warning="Empty data extraction for selected ROI" if empty_roi_warning else None,
    )


def _raster_info_to_dict(raster_info: RasterInfo) -> dict:
    """Converting RasterInfo object to dictionary.

    Parameters
    ----------
    raster_info : RasterInfo
        raster info from DEM roi extraction

    Returns
    -------
    dict
        dict from input raster info
    """
    return {
        "lines": raster_info.lines,
        "lines_start": raster_info.lines_start,
        "lines_step": raster_info.lines_step,
        "lines_units": raster_info.lines_start_unit,
        "samples": raster_info.samples,
        "samples_start": raster_info.samples_start,
        "samples_step": raster_info.samples_step,
        "samples_units": raster_info.samples_start_unit,
        "celltype": raster_info.cell_type.name,
        "filename": raster_info.file_name,
        "header_offset_bytes": raster_info.header_offset_bytes,
        "row_prefix_bytes": raster_info.row_prefix_bytes,
        "byteorder": raster_info.byte_order.name,
    }
