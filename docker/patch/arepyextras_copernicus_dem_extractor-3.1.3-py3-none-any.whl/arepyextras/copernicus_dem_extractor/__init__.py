# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
Copernicus DEM (Digital Elevation Model) Extractor package
----------------------------------------------------------
"""
from __future__ import annotations

from arepyextras.copernicus_dem_extractor.core import extract_data, extract_data_to_pf
from arepyextras.copernicus_dem_extractor.core.index import generate_index

__version__ = "3.1.3"
