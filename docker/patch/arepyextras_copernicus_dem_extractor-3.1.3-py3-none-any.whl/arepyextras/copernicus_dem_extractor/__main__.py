# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""Copernicus DEM (Digital Elevation Model) Extractor main script"""

from arepyextras.copernicus_dem_extractor.core.cli import cli


def main():
    """Main Package CLI entry point"""
    cli()


if __name__ == "__main__":
    main()
