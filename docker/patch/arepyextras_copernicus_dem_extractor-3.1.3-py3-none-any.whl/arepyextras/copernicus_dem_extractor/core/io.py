# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""DEM Input file reader module"""
from __future__ import annotations

import math
from dataclasses import dataclass
from functools import singledispatch
from pathlib import Path
from typing import Union

import numpy as np
from osgeo import gdal
from xsdata.formats.dataclass.parsers import XmlParser
from xsdata.formats.dataclass.parsers.config import ParserConfig

from arepyextras.copernicus_dem_extractor.core import models
from arepyextras.copernicus_dem_extractor.core.extractor import (
    Egm2008,
    VerticalCrs,
    Wgs84,
)
from arepyextras.copernicus_dem_extractor.core.geometry import (
    Angle,
    CircleInterval,
    Interval,
    LatLonRectangle,
)

gdal.UseExceptions()


@dataclass
class InputFile:
    """Input File data model"""

    dem_index_filename: str | Path
    roi: LatLonRectangle
    output: str | Path
    vertical_crs: VerticalCrs


def angle_from_xml_model(xml_angle: models.AngleValue) -> Angle:
    """Get Angle with correct unit of measure from angle specified in xml.

    Parameters
    ----------
    xml_angle : models.AngleValue
        angle value in xml file

    Returns
    -------
    Angle
        Angle object, value in degrees

    Raises
    ------
    ValueError
        if angle unit of measure is not in degree or radians
    """
    if xml_angle.unit == models.AngleValueUnit.DEG:
        return Angle(xml_angle.value)
    if xml_angle.unit == models.AngleValueUnit.RAD:
        return Angle(math.degrees(xml_angle.value))

    raise ValueError("unexpected angle unit")


@singledispatch
def vertical_crs_from_xml_model(xml_vertical_crs) -> VerticalCrs:
    """Vertical CRS not supported"""
    raise ValueError("unsupported vertical CRS")


@vertical_crs_from_xml_model.register
def _(xml_vertical_crs: models.Egm2008) -> Egm2008:
    return Egm2008()


@vertical_crs_from_xml_model.register
def _(xml_vertical_crs: models.Wgs84) -> Wgs84:
    return Wgs84(egm2008_geoid_filename=xml_vertical_crs.egm2008_geoid_filename)


def read_input_file(filename: Union[str, Path], step_number: int) -> InputFile:
    """Read input XML file.

    Parameters
    ----------
    filename : PathLike
        Path to the .XML input file
    step_number : int
        number of steps (extraction requests) to be performed

    Returns
    -------
    InputFile
        InputFile dataclass corresponding to input file info

    Raises
    ------
    RuntimeError
        if no step number is given
    RuntimeError
        if CopernicusDEMImport section is missing
    """
    parser = XmlParser(config=ParserConfig(fail_on_unknown_properties=False))

    filename = Path(filename)
    xml_input_file = parser.from_path(filename, models.AresysInput)

    for step in xml_input_file.steps:
        if step.number == step_number:
            break
    else:
        raise RuntimeError(f"step {step_number} is missing")

    if step.copernicus_dem_import is None:
        raise RuntimeError("section 'CopernicusDEMImport' is missing")

    return InputFile(
        dem_index_filename=Path(step.copernicus_dem_import.dem_index_filename),
        roi=LatLonRectangle(
            lat=Interval(
                angle_from_xml_model(step.copernicus_dem_import.roi.south_coordinate),
                angle_from_xml_model(step.copernicus_dem_import.roi.north_coordinate),
            ),
            lon=CircleInterval(
                angle_from_xml_model(step.copernicus_dem_import.roi.west_coordinate),
                angle_from_xml_model(step.copernicus_dem_import.roi.east_coordinate),
            ),
        ),
        output=step.copernicus_dem_import.output.product,
        vertical_crs=vertical_crs_from_xml_model(step.copernicus_dem_import.output.vertical_crs.value),
    )


def create_input_file_from_args(
    dem_index_file_path: Union[str, Path],
    roi: tuple[float, float, float, float],
    output_path: Union[str, Path],
    path_to_egm2008_tif: Union[str, Path] | None = None,
) -> InputFile:
    """Assembling a InputFile dataclass from input arguments.

    Parameters
    ----------
    dem_index_file_path : Union[str, Path]
        path to the DEM index .XML file
    roi : tuple[float, float, float, float]
        roi to be extracted, a tuple with 4 values in the format:

            - Minimum Longitude Value [deg] (West Coordinate) [0]
            - Maximum Longitude Value [deg] (East Coordinate) [1]
            - Minimum Latitude Value [deg] (South Coordinate) [2]
            - Maximum Latitude Value [deg] (North Coordinate) [3]

    output_path : Union[str, Path]
        path to the output product folder to be saved
    path_to_egm2008_tif : Union[str, Path] | None, optional
        if specified, the elevation data extracted are converted to WGS84 model

    Returns
    -------
    InputFile
        InputFile dataclass corresponding to input arguments

    Raises
    ------
    RuntimeError
        invalid conversion tif file for WGS84 model
    """
    # converting input roi to valid Angle dataclasses
    assert len(roi) == 4
    roi_angles = [models.AngleValue(c) for c in roi]

    # converting input vertical crs to valid dataclass
    if path_to_egm2008_tif is not None:
        path_to_egm2008_tif = Path(path_to_egm2008_tif)
        if not path_to_egm2008_tif.is_file():
            raise RuntimeError(f"Invalid egm2008 conversion tif file {path_to_egm2008_tif}")
        vertical_crs = models.Wgs84(egm2008_geoid_filename=str(path_to_egm2008_tif))
    else:
        vertical_crs = models.Egm2008()

    return InputFile(
        dem_index_filename=Path(dem_index_file_path),
        roi=LatLonRectangle(
            lat=Interval(
                angle_from_xml_model(roi_angles[2]),  # south coordinate
                angle_from_xml_model(roi_angles[3]),  # north coordinate
            ),
            lon=CircleInterval(
                angle_from_xml_model(roi_angles[0]),  # west coordinate
                angle_from_xml_model(roi_angles[1]),  # east coordinate
            ),
        ),
        output=Path(output_path),
        vertical_crs=vertical_crs_from_xml_model(vertical_crs),
    )
