# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""DEM Geometry module"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any, Generic, NewType, TypeVar

Angle = NewType("Angle", float)


def normalize_angle(degrees: Angle) -> Angle:
    """The angle normalized to the range (-180, 180]"""
    radians = math.radians(degrees)
    radians = math.atan2(math.sin(radians), math.cos(radians))
    return Angle(math.degrees(radians))


T = TypeVar("T", float, Angle)


@dataclass
class Interval(Generic[T]):
    """A closed, bounded interval on the real line"""

    lower: T
    upper: T

    def contains(self, value: T) -> bool:
        """Check if a value is contained in the interval"""
        return self.lower <= value <= self.upper

    def intersects(self, other: Interval) -> bool:
        """Check if the intersection of two intervals is not empty"""
        return self.lower <= other.upper and other.lower <= self.upper

    def length(self) -> T:
        """Measure the length of the interval, empty intervals have null measure"""
        return max(0, self.upper - self.lower)

    def is_empty(self) -> bool:
        """Check if the interval is empty"""
        return self.length() == 0

    @staticmethod
    def empty():
        """Construct an empty interval"""
        return Interval(math.inf, -math.inf)


@dataclass
class CircleInterval:
    """A closed interval on a unit circle, moving from to lower to upper in counterclockwise direction"""

    lower: Angle
    upper: Angle

    def contains(self, value: Angle) -> bool:
        """Check if a value is contained in the interval"""
        value = normalize_angle(value)
        if self.lower <= self.upper:
            return self.lower <= value <= self.upper
        else:
            return self.lower <= value or value <= self.upper

    def intersects(self, other: CircleInterval) -> bool:
        """Check if the intersection of two intervals is not empty"""
        return (
            self.contains(other.lower)
            or self.contains(other.upper)
            or other.contains(self.lower)
            or other.contains(self.upper)
        )

    def length(self) -> Angle:
        """Measure the length of the interval"""
        delta = self.upper - self.lower
        return Angle(delta if delta >= 0 else 360 + delta)

    def is_empty(self) -> bool:
        """Check if the interval is empty"""
        return self.length() == 0


@dataclass
class LatLonRectangle:
    """A closed latitude-longitude rectangle"""

    lat: Interval
    lon: CircleInterval

    def intersects(self, other: LatLonRectangle) -> bool:
        """Check if the intersection of two rectangles is not empty"""
        return self.lat.intersects(other.lat) and self.lon.intersects(other.lon)

    def is_empty(self) -> bool:
        """Check if the rectangle is empty"""
        return self.lat.is_empty() or self.lon.is_empty()


@dataclass
class LatLonPair:
    """A generic pair of values associated to latitude and longitude"""

    lat: Any
    lon: Any
