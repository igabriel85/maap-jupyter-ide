# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""DEM objects models"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class AngleValueUnit(Enum):
    RAD = "rad"
    DEG = "deg"


class ArchiveType(Enum):
    GZIP = "GZIP"
    TAR = "TAR"
    ZIP = "ZIP"


@dataclass
class AngleValue:
    value: float
    unit: AngleValueUnit = field(default=AngleValueUnit.DEG, metadata={"type": "Attribute"})


@dataclass
class TileLocation:
    filename: str = field(metadata={"name": "Filename", "type": "Element"})
    archive: Optional[TileLocation.Archive] = field(default=None, metadata={"name": "Archive", "type": "Element"})

    @dataclass
    class Archive:
        filename: str = field(metadata={"name": "Filename", "type": "Element"})
        archive_type: ArchiveType = field(metadata={"name": "ArchiveType", "type": "Element"})


@dataclass
class TileExtent:
    latitude_extent: TileExtent.LatitudeExtent = field(metadata={"name": "LatitudeExtent", "type": "Element"})
    longitude_extent: TileExtent.LongitudeExtent = field(metadata={"name": "LongitudeExtent", "type": "Element"})

    @dataclass
    class LatitudeExtent:
        latitude_lower: AngleValue = field(metadata={"name": "LatitudeLower", "type": "Element"})
        latitude_upper: AngleValue = field(metadata={"name": "LatitudeUpper", "type": "Element"})

    @dataclass
    class LongitudeExtent:
        longitude_lower: AngleValue = field(metadata={"name": "LongitudeLower", "type": "Element"})
        longitude_upper: AngleValue = field(metadata={"name": "LongitudeUpper", "type": "Element"})


@dataclass
class Tile:
    tile_location: TileLocation = field(metadata={"name": "TileLocation", "type": "Element"})
    tile_extent: TileExtent = field(metadata={"name": "TileExtent", "type": "Element"})


@dataclass
class DemIndex:
    class Meta:
        name = "DemIndex"

    tile_list: DemIndex.TileList = field(metadata={"name": "TileList", "type": "Element"})

    @dataclass
    class TileList:
        tiles: List[Tile] = field(default_factory=list, metadata={"name": "Tile", "type": "Element"})


@dataclass
class Wgs84:
    egm2008_geoid_filename: str = field(metadata={"name": "EGM2008GeoidFileName", "type": "Element"})


@dataclass
class Egm2008:
    pass


@dataclass
class VerticalCrs:
    value: object = field(
        metadata={
            "type": "Elements",
            "choices": (
                {"name": "WGS84", "type": Wgs84},
                {"name": "EGM2008", "type": Egm2008},
            ),
            "required": True,
        }
    )


@dataclass
class Output:
    product: str = field(metadata={"name": "Product"})
    vertical_crs: VerticalCrs = field(metadata={"name": "VerticalCRS"})


@dataclass
class Roi:
    east_coordinate: AngleValue = field(metadata={"name": "EastCoordinate", "type": "Element"})
    west_coordinate: AngleValue = field(metadata={"name": "WestCoordinate", "type": "Element"})
    north_coordinate: AngleValue = field(metadata={"name": "NorthCoordinate", "type": "Element"})
    south_coordinate: AngleValue = field(metadata={"name": "SouthCoordinate", "type": "Element"})


@dataclass
class CopernicusDEMImport:
    dem_index_filename: str = field(metadata={"name": "DemIndexFileName", "type": "Element"})
    roi: Roi = field(metadata={"name": "ROI", "type": "Element"})
    output: Output = field(metadata={"name": "Output", "type": "Element"})


@dataclass
class Step:
    number: int = field(metadata={"type": "Attribute", "name": "Number"})
    copernicus_dem_import: Optional[CopernicusDEMImport] = field(
        default=None, metadata={"name": "CopernicusDEMImport", "type": "Element"}
    )


@dataclass
class AresysInput:
    steps: List[Step] = field(default_factory=list, metadata={"name": "Step", "type": "Element", "min_occurs": 1})
