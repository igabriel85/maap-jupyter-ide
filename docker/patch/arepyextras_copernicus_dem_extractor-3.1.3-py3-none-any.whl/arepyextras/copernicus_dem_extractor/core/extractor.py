# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""Extractor module"""

from __future__ import annotations

import math
import shutil
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import numpy as np
import tifffile
from arepytools.io import (
    create_new_metadata,
    create_product_folder,
    write_metadata,
    write_raster_with_raster_info,
)
from arepytools.io.metadata import ECellType, RasterInfo
from osgeo import gdal, osr

from arepyextras.copernicus_dem_extractor.core.geometry import (
    LatLonPair,
    LatLonRectangle,
)
from arepyextras.copernicus_dem_extractor.core.index import load_index

DEFAULT_RESOLUTION = LatLonPair(200, 200)


class EmptyRegionWarning(Warning):
    """Custom warning to alert of empty ROI extraction (no tiles overlapping on selected region)"""


class VerticalCrs:
    pass


class Egm2008(VerticalCrs):
    pass


@dataclass
class Wgs84(VerticalCrs):
    egm2008_geoid_filename: str

    def __post_init__(self):
        if not Path(self.egm2008_geoid_filename).exists():
            raise FileNotFoundError(self.egm2008_geoid_filename)


class CopernicusDemExtractor:
    """Main DEM Extractor Class"""

    def __init__(self, dem_index_filename: Union[str, Path]):
        self._tiles = load_index(dem_index_filename)

    def extract_to_disk(self, roi: LatLonRectangle, vertical_crs: VerticalCrs, output: Union[str, Path]) -> None:
        """Extracting data as per input request and saving them to Aresys Product Folder format to disk.

        Parameters
        ----------
        roi : LatLonRectangle
            extraction roi requested
        output : Union[str, Path]
            Path to the Product Folder to be created as output
        vertical_crs : VerticalCrs
            Vertical Coordinates system

        Raises
        ------
        ValueError
            input roi is empty
        ValueError
            unsupported vertical coordinates system
        RuntimeError
            error while extracting info from DEM dataset
        """
        if roi.is_empty():
            raise ValueError("selected region is empty")

        output = Path(output)
        output_product = create_product_folder(output)
        channel = 1
        intermediate_folder = output.joinpath("intermediate")
        intermediate_folder.mkdir()

        try:
            selected_tiles = [tile.gdal_uri for tile in self._tiles if tile.extent.intersects(roi)]

            max_resolution = max_resolution_from_tiles(selected_tiles)
            if max_resolution is None:
                max_resolution = DEFAULT_RESOLUTION

            # extracting DEM elevation data using GDAL and saving them as tif files
            raster_info = extract_data_to_tiff(
                roi=roi,
                selected_tiles=selected_tiles,
                max_resolution=max_resolution,
                vertical_crs=vertical_crs,
                out_fldr=intermediate_folder,
                filename=output_product.get_channel_data(channel).name,
            )

            # loading egm2008 data from extracted tif
            if isinstance(vertical_crs, Wgs84):
                tiff_path = intermediate_folder.joinpath("wgs84_dem.tif")
            elif isinstance(vertical_crs, Egm2008):
                tiff_path = intermediate_folder.joinpath("egm2008_dem.tif")
            else:
                raise ValueError("unsupported vertical CRS")
            data = _open_geotiff(tiff_path)

            _write_array_to_product_channel(
                raster_file=output_product.get_channel_data(channel),
                raster_info=raster_info,
                metadata_file=output_product.get_channel_metadata(channel),
                data=data,
            )

        except Exception as err:
            raise RuntimeError from err
        finally:
            shutil.rmtree(intermediate_folder)


def _open_geotiff(filename: Union[str, Path]) -> np.ndarray:
    """Reading input geotiff file as a numpy array using GDAL.

    Parameters
    ----------
    filename : Union[str, Path]
        path to the geotiff file

    Returns
    -------
    np.ndarray
        image as array
    """
    ds = gdal.Open(str(filename), gdal.GA_ReadOnly)
    rb = ds.GetRasterBand(1)
    return rb.ReadAsArray()


def max_resolution_from_tiles(tiles_uri: list[str]) -> Optional[LatLonPair]:
    if not tiles_uri:
        return None

    resolution = LatLonPair(0, 0)
    for tile_uri in tiles_uri:
        dataset = gdal.Open(tile_uri, gdal.GA_ReadOnly)

        _, lon, _, _, _, lat = dataset.GetGeoTransform()

        resolution = LatLonPair(
            lat=max(resolution.lat, abs(1 / lat)),
            lon=max(resolution.lon, abs(1 / lon)),
        )

    return resolution


def _create_destination_dataset(
    filename: Union[str, Path], roi: LatLonRectangle, resolution: LatLonPair
) -> gdal.Dataset:
    size = LatLonPair(
        lat=math.ceil(roi.lat.length() * resolution.lat) + 1,
        lon=math.ceil(roi.lon.length() * resolution.lon) + 1,
    )

    driver = gdal.GetDriverByName("GTiff")
    dataset = driver.Create(str(filename), size.lon, size.lat, 1, gdal.GDT_Float32)

    projection = osr.SpatialReference()
    projection.ImportFromEPSG(4326)
    projection = projection.ExportToWkt()
    dataset.SetProjection(projection)

    pixelsize = LatLonPair(
        lat=roi.lat.length() / (size.lat - 1),
        lon=roi.lon.length() / (size.lon - 1),
    )
    upperleft = LatLonPair(
        lat=roi.lat.upper + pixelsize.lat / 2,
        lon=roi.lon.lower - pixelsize.lon / 2,
    )
    transform = (upperleft.lon, pixelsize.lon, 0, upperleft.lat, 0, -pixelsize.lat)
    dataset.SetGeoTransform(transform)

    band = dataset.GetRasterBand(1)
    band.Fill(0.0)
    band.SetNoDataValue(math.nan)

    return dataset


def _merge_tiles(tiles_uri: list[str], output_file: gdal.Dataset):
    if tiles_uri:
        options = {"resampleAlg": "bilinear"}
        gdal.Warp(output_file, tiles_uri, **options)
        # force writing data to disk
        output_file.FlushCache()


def _write_array_to_product_channel(
    raster_file: Path, metadata_file: Path, raster_info: RasterInfo, data: np.ndarray
) -> None:
    """Write array to product folder channel.

    Parameters
    ----------
    raster_file : Path
        file to raster file path
    metadata_file : Path
        file to metadata file path
    raster_info : RasterInfo
        raster info data
    data : np.ndarray
        data to be written
    """
    metadata = create_new_metadata()
    metadata.insert_element(raster_info)

    write_raster_with_raster_info(raster_file=raster_file, data=data, raster_info=raster_info)
    write_metadata(metadata_obj=metadata, metadata_file=metadata_file)


def extract_data_to_tiff(
    roi: LatLonRectangle,
    selected_tiles: list[str],
    max_resolution: LatLonPair,
    vertical_crs: VerticalCrs,
    out_fldr: Union[str, Path],
    filename: Union[str, None] = None,
) -> RasterInfo:
    """Extracting elevation data from DEM and dumping them to tif files on disk.

    Parameters
    ----------
    roi : LatLonRectangle
        extraction roi requested
    selected_tiles : list[str]
        list of gdal uri tiles where roi selection lies
    max_resolution : LatLonPair
        maximum lat/lon resolution values
    vertical_crs : VerticalCrs
        Vertical Coordinates system
    out_fldr : Union[str, Path]
        Path to the Product Folder to be created as output
    filename : Union[str, None], optional
        RasterInfo filename field, by default None

    Returns
    -------
    RasterInfo
        extracted data raster info
    """
    out_fldr = Path(out_fldr)
    if not out_fldr.is_dir():
        raise RuntimeError("Output directory does not exist or is not a valid folder")

    extracted_dataset_filename = out_fldr.joinpath("egm2008_dem.tif")
    extracted_dataset = _create_destination_dataset(extracted_dataset_filename, roi, max_resolution)
    samples, lines = extracted_dataset.RasterXSize, extracted_dataset.RasterYSize
    start_x, step_x, _, start_y, _, step_y = extracted_dataset.GetGeoTransform()
    if len(selected_tiles) == 0:
        warnings.warn(
            "No overlapping tiles have been found for the selected ROI, extracted values forced to 0",
            category=EmptyRegionWarning,
        )
        tifffile.imwrite(extracted_dataset_filename, np.zeros((lines, samples), dtype=np.float32))
    else:
        _merge_tiles(selected_tiles, extracted_dataset)

    raster_info = RasterInfo(
        lines=lines,
        samples=samples,
        celltype=ECellType.float32,
        filename=extracted_dataset_filename.name if filename is None else filename,
    )
    raster_info.set_samples_axis(start_x + step_x / 2, "deg", step_x, "deg")
    raster_info.set_lines_axis(start_y + step_y / 2, "deg", step_y, "deg")

    if isinstance(vertical_crs, Wgs84):
        geoid_dataset_filename = out_fldr.joinpath("egm2008_geoid.tif")
        geoid_dataset = _create_destination_dataset(geoid_dataset_filename, roi, max_resolution)
        _merge_tiles([vertical_crs.egm2008_geoid_filename], geoid_dataset)
        wgs84_dataset_filename = out_fldr.joinpath("wgs84_dem.tif")
        wgs84_dataset = _open_geotiff(extracted_dataset_filename) + _open_geotiff(geoid_dataset_filename)
        tifffile.imwrite(wgs84_dataset_filename, wgs84_dataset, dtype=np.float32)

    return raster_info
