# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""Copernicus DEM Extractor CLI tool"""

from __future__ import annotations

from pathlib import Path

import click
from osgeo import gdal

from arepyextras.copernicus_dem_extractor.core import extract_data_with_input_file
from arepyextras.copernicus_dem_extractor.core.index import (
    generate_index as _generate_index,
)

gdal.UseExceptions()


## command line interface
## ----------------------------------------------------------------------------
@click.group(
    context_settings=dict(
        help_option_names=["-h", "--help"],
    )
)
def cli():
    """Copernicus DEM extractor"""


@click.command()
@click.argument("input_file", type=click.Path(exists=True))
@click.argument("step_number", type=click.INT)
def extract(input_file: Path, step_number: int):
    """Extract a region from Copernicus DEM database."""
    try:
        extract_data_with_input_file(input_file, step_number)
    except Exception as exc:
        raise click.ClickException(str(exc))


@click.command()
@click.option(
    "-p", "--path", type=click.Path(exists=True, dir_okay=True), required=True, help="Path to the Copernicus DEM folder"
)
@click.option("-i", "--index", type=click.Path(), required=False, default=None, help="Name of the index file, optional")
def generate_index(path: Path, index: Path | None):
    """Generate Copernicus DEM Index file"""
    _generate_index(dem_path=path, index_filename=index)


cli.add_command(extract)
cli.add_command(generate_index)
