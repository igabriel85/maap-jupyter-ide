# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""
Extractor Core Module
---------------------
"""
from __future__ import annotations

import shutil
import warnings
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Union

import numpy as np
import tifffile
from arepytools.io.metadata import RasterInfo

from arepyextras.copernicus_dem_extractor.core.extractor import (
    DEFAULT_RESOLUTION,
    CopernicusDemExtractor,
    Egm2008,
    Wgs84,
    extract_data_to_tiff,
    max_resolution_from_tiles,
)
from arepyextras.copernicus_dem_extractor.core.index import load_index
from arepyextras.copernicus_dem_extractor.core.io import (
    create_input_file_from_args,
    read_input_file,
)


def extract_data_with_input_file(input_file_path: Union[str, Path], step_number: int) -> None:
    """Extract elevation data from DEM corresponding to the region in the input file XML.

    Parameters
    ----------
    input_file_path : Union[str, Path]
        Path to the input .xml file
    step_number : int
        extraction step number, it selects just the extraction request corresponding
        to that step number in the input file
    """
    user_input = read_input_file(input_file_path, step_number)
    dem_extractor_object = CopernicusDemExtractor(user_input.dem_index_filename)
    dem_extractor_object.extract_to_disk(
        roi=user_input.roi, output=user_input.output, vertical_crs=user_input.vertical_crs
    )


def extract_data_to_pf(
    dem_index_file_path: Union[str, Path],
    roi: tuple[float, float, float, float],
    output_path: Union[str, Path],
    path_to_egm2008_tif: Union[str, Path] | None = None,
) -> None:
    """Extract elevation data from DEM corresponding to the requested ROI and saving results to Product Folder.

    Parameters
    ----------
    dem_index_file_path : Union[str, Path]
        path to the DEM index .XML file
    roi : tuple[float, float, float, float]
        roi to be extracted, a tuple with 4 values in the format:

            - Minimum Longitude Value [deg] (West Coordinate) [0]
            - Maximum Longitude Value [deg] (East Coordinate) [1]
            - Minimum Latitude Value [deg] (South Coordinate) [2]
            - Maximum Latitude Value [deg] (North Coordinate) [3]

    output_path : Union[str, Path]
        path to the output product folder to be saved
    path_to_egm2008_tif : Union[str, Path] | None, optional
        if specified, the elevation data extracted are converted to WGS84 model,
        by default output is expressed in EGM2008 (if not specified the output is left in EGM2008), by default None
    """

    if path_to_egm2008_tif is None:
        warnings.warn("Output vertical crs is EGM2008 and not WGS84")

    input_file = create_input_file_from_args(
        dem_index_file_path=dem_index_file_path,
        roi=roi,
        output_path=output_path,
        path_to_egm2008_tif=path_to_egm2008_tif,
    )
    dem_extractor_object = CopernicusDemExtractor(input_file.dem_index_filename)
    dem_extractor_object.extract_to_disk(input_file.roi, input_file.vertical_crs, output_path)


def extract_data(
    dem_index_file_path: Union[str, Path],
    roi: tuple[float, float, float, float],
    path_to_egm2008_tif: Union[str, Path] | None = None,
) -> tuple[np.ndarray, RasterInfo]:
    """Extract elevation data from DEM corresponding to the requested ROI.

    Parameters
    ----------
    dem_index_file_path : Union[str, Path]
        path to the DEM index .XML file
    roi : tuple[float, float, float, float]
        roi to be extracted, a tuple with 4 values in the format:

            - Minimum Longitude Value [deg] (West Coordinate) [0]
            - Maximum Longitude Value [deg] (East Coordinate) [1]
            - Minimum Latitude Value [deg] (South Coordinate) [2]
            - Maximum Latitude Value [deg] (North Coordinate) [3]

    path_to_egm2008_tif : Union[str, Path] | None, optional
        if specified, the elevation data extracted are converted to WGS84 model using the geoid .tif file provided,
        by default output is expressed in EGM2008 (if not specified the output is left in EGM2008), by default None

    Returns
    -------
    tuple[np.ndarray, RasterInfo]
        extracted elevation data array,
        RasterInfo related to extracted data
    """

    input_file = create_input_file_from_args(
        dem_index_file_path=dem_index_file_path,
        roi=roi,
        output_path="",
        path_to_egm2008_tif=path_to_egm2008_tif,
    )

    tiles = load_index(index_filename=input_file.dem_index_filename)

    if input_file.roi.is_empty():
        raise ValueError("selected region is empty")

    with TemporaryDirectory() as temp_dir:
        cop_dem_extractor = Path(temp_dir).joinpath("cop_dem_extractor")
        cop_dem_extractor.mkdir()
        try:
            selected_tiles = [tile.gdal_uri for tile in tiles if tile.extent.intersects(input_file.roi)]

            max_resolution = max_resolution_from_tiles(selected_tiles)
            if max_resolution is None:
                max_resolution = DEFAULT_RESOLUTION

            # extracting data from DEM
            raster_info = extract_data_to_tiff(
                roi=input_file.roi,
                selected_tiles=selected_tiles,
                max_resolution=max_resolution,
                vertical_crs=input_file.vertical_crs,
                out_fldr=cop_dem_extractor,
            )

            # loading the proper tiff file
            if isinstance(input_file.vertical_crs, Wgs84):
                tiff_path = cop_dem_extractor.joinpath("wgs84_dem.tif")
            elif isinstance(input_file.vertical_crs, Egm2008):
                tiff_path = cop_dem_extractor.joinpath("egm2008_dem.tif")
            else:
                raise ValueError("unsupported vertical CRS")

            data = tifffile.imread(tiff_path)
        except Exception as err:
            raise RuntimeError("DEM extraction failed") from err
        finally:
            shutil.rmtree(cop_dem_extractor)

    return data, raster_info
