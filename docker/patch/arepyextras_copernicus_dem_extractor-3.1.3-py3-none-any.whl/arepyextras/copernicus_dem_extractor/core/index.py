# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""DEM Index manager module"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from pathlib import Path
from tarfile import TarFile
from typing import Optional, Union

from osgeo import gdal
from xsdata.formats.dataclass.parsers.xml import XmlParser
from xsdata.formats.dataclass.serializers import XmlSerializer, config

from arepyextras.copernicus_dem_extractor.core import models
from arepyextras.copernicus_dem_extractor.core.geometry import (
    Angle,
    CircleInterval,
    Interval,
    LatLonRectangle,
    normalize_angle,
)


@dataclass(frozen=True)
class Tile:
    gdal_uri: str
    extent: LatLonRectangle

    @classmethod
    def from_xml_model(cls, tile: models.Tile, prefix: Optional[Union[str, Path]] = None) -> Tile:
        gdal_uri = cls._gdal_uri_from_xml_model(tile.tile_location, prefix)
        extent = cls._extent_from_xml_model(tile.tile_extent)

        return cls(gdal_uri=gdal_uri, extent=extent)

    @classmethod
    def _gdal_uri_from_xml_model(
        cls, tile_location: models.TileLocation, prefix: Optional[Union[str, Path]] = None
    ) -> str:
        if prefix is not None:
            prefix = Path(prefix)

        if tile_location.archive is None:
            gdal_uri = tile_location.filename
            if not Path(gdal_uri).is_absolute() and prefix is not None:
                gdal_uri = prefix.joinpath(gdal_uri)

            return str(gdal_uri)

        gdal_driver = {
            models.ArchiveType.GZIP: "vsigzip",
            models.ArchiveType.TAR: "vsitar",
            models.ArchiveType.ZIP: "vsizip",
        }[tile_location.archive.archive_type]

        archive = tile_location.archive.filename
        if not Path(archive).is_absolute() and prefix is not None:
            archive = prefix.joinpath(archive)

        filename = tile_location.filename

        return "/{}/{}/{}".format(gdal_driver, archive, filename)

    @classmethod
    def _extent_from_xml_model(cls, tile_extent: models.TileExtent):
        lat_extent = Interval(
            cls._angle_from_xml_model(tile_extent.latitude_extent.latitude_lower),
            cls._angle_from_xml_model(tile_extent.latitude_extent.latitude_upper),
        )
        lon_extent = CircleInterval(
            cls._angle_from_xml_model(tile_extent.longitude_extent.longitude_lower),
            cls._angle_from_xml_model(tile_extent.longitude_extent.longitude_upper),
        )

        return LatLonRectangle(lat=lat_extent, lon=lon_extent)

    @classmethod
    def _angle_from_xml_model(cls, angle_value: models.AngleValue) -> Angle:
        if angle_value.unit == models.AngleValueUnit.DEG:
            return Angle(angle_value.value)

        if angle_value.unit == models.AngleValueUnit.RAD:
            return Angle(math.degrees(angle_value.value))

        raise ValueError("unexpected angle unit")


def load_index(index_filename: Union[str, Path]) -> list[Tile]:
    dem_index_filename = Path(index_filename)
    prefix = dem_index_filename.absolute().parent

    xml_parser = XmlParser()
    dem_index = xml_parser.from_path(dem_index_filename, models.DemIndex)

    return [Tile.from_xml_model(tile, prefix) for tile in dem_index.tile_list.tiles]


def generate_index(dem_path: Union[str, Path], index_filename: Union[str, Path] | None = None) -> None:
    """Generate DEM index file for the selected DEM dataset.

    Parameters
    ----------
    dem_path : Union[str, Path]
        Path to the local DEM dataset
    index_filename : Union[str, Path] | None, optional
        name of the index file, it must be provided as a full filename path with .XML extension, by default None

    Raises
    ------
    NotADirectoryError
        if DEM path does not lead to a directory
    """
    dem_path = Path(dem_path)

    if not dem_path.is_dir():
        raise NotADirectoryError(dem_path)

    index_filename = (
        Path(index_filename) if index_filename is not None else dem_path.joinpath("demIndex").with_suffix(".xml")
    )

    # os.chdir(dem_path)

    xml_tile_list = models.DemIndex.TileList()

    for filename in dem_path.rglob("*"):
        extensions = filename.suffixes
        if extensions == [".DEM", ".tar"]:
            xml_tile_location = _xml_tile_location_from_archive(filename, dem_path)
        elif extensions in (".dt1", ".tif"):
            xml_tile_location = _xml_tile_location_from_file(filename, dem_path)
        else:
            continue

        xml_tile = _xml_tile_from_xml_tile_location(xml_tile_location, dem_path)
        xml_tile_list.tiles.append(xml_tile)

    xml_root = models.DemIndex(xml_tile_list)

    serializer_config = config.SerializerConfig(pretty_print=True, pretty_print_indent="\t")
    serializer = XmlSerializer(config=serializer_config)
    index_filename.write_text(serializer.render(xml_root), encoding="UTF-8")


def _xml_tile_location_from_archive(archive: Path, prefix: Optional[Union[str, Path]] = None) -> Optional[models.Tile]:
    with TarFile(archive, "r") as tarfile:
        for filename in map(Path, tarfile.getnames()):
            if filename.parent.name == "DEM":
                if filename.suffix == ".dt1" or filename.suffix == ".tif":
                    break
        else:
            return None

    archive_filename = archive.absolute()
    if prefix is not None:
        archive_filename = archive_filename.relative_to(prefix)

    return models.TileLocation(
        filename=str(filename),
        archive=models.TileLocation.Archive(
            filename=str(archive_filename),
            archive_type=models.ArchiveType.TAR,
        ),
    )


def _xml_tile_location_from_file(filename: Path, prefix: Optional[Union[str, Path]] = None) -> Optional[models.Tile]:
    if filename.suffix != ".dt1" and filename.suffix != ".tif":
        return None

    if prefix is not None:
        filename = filename.relative_to(prefix)

    return models.TileLocation(filename=str(filename))


def _xml_tile_from_xml_tile_location(
    xml_location: models.TileLocation, prefix: Optional[Union[str, Path]] = None
) -> models.Tile:
    extent = _get_tile_extent(Tile._gdal_uri_from_xml_model(xml_location, prefix))

    return models.Tile(
        tile_location=xml_location,
        tile_extent=models.TileExtent(
            latitude_extent=models.TileExtent.LatitudeExtent(
                latitude_lower=models.AngleValue(extent.lat.lower, models.AngleValueUnit.DEG),
                latitude_upper=models.AngleValue(extent.lat.upper, models.AngleValueUnit.DEG),
            ),
            longitude_extent=models.TileExtent.LongitudeExtent(
                longitude_lower=models.AngleValue(extent.lon.lower, models.AngleValueUnit.DEG),
                longitude_upper=models.AngleValue(extent.lon.upper, models.AngleValueUnit.DEG),
            ),
        ),
    )


def _get_tile_extent(gdal_uri: str) -> LatLonRectangle:
    dataset = gdal.Open(gdal_uri, gdal.GA_ReadOnly)

    ulx, xres, _, uly, _, yres = dataset.GetGeoTransform()
    lrx = ulx + (dataset.RasterXSize * xres)
    lry = uly + (dataset.RasterYSize * yres)

    lower_x, upper_x = min(lrx, ulx), max(lrx, ulx)
    lower_y, upper_y = min(lry, uly), max(lry, uly)

    lower_x += abs(xres) / 2
    upper_x -= abs(xres) / 2

    lower_y += abs(yres) / 2
    upper_y -= abs(yres) / 2

    lat = Interval(lower_y, upper_y)
    lon = CircleInterval(normalize_angle(lower_x), normalize_angle(upper_x))

    return LatLonRectangle(lat, lon)
