# SPDX-FileCopyrightText: Aresys S.r.l. <info@aresys.it>
# SPDX-License-Identifier: MIT

"""Copernicus DEM Extractor - Testing Index Generation"""

from arepyextras.copernicus_dem_extractor.core import (
    extract_data,
    extract_data_to_pf,
    extract_data_with_input_file,
)
from arepyextras.copernicus_dem_extractor.core.index import generate_index

if __name__ == "__main__":
    # dem_path = r"/home/test/dem/"
    # input_file = r"/home/test/develop/scripts/prova_input_file.xml"
    product = r"/home/test/prodotto_original"

    data, raster_info = extract_data(
        dem_index_file_path=r"/home/test/dem/demIndex.xml",
        roi=(5, 5.2, 1, 1.1),
        path_to_egm2008_tif=r"/home/test/dem/egm2008-1.tif",
    )

    # from arepytools.io import open_product_folder, read_raster_with_raster_info, read_metadata

    # pf = open_product_folder(product)
    # mtd = read_metadata(pf.get_channel_metadata(1))
    # raster_info = mtd.get_raster_info()
    # data = read_raster_with_raster_info(pf.get_channel_data(1), raster_info)

    pass
